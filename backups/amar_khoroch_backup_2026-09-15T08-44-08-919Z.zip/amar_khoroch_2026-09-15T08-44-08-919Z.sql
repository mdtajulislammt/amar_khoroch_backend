--
-- PostgreSQL database dump
--

\restrict TdnH9M4s5QMNGxDd5idVbPccCyDdttOkRDPsozdn2K3II9e5OLPfyb9irmh0tr0

-- Dumped from database version 15.19
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AccountStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AccountStatus" AS ENUM (
    'ACTIVE',
    'SUSPENDED',
    'BANNED'
);


ALTER TYPE public."AccountStatus" OWNER TO postgres;

--
-- Name: AnnouncementType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AnnouncementType" AS ENUM (
    'INFO',
    'WARNING',
    'URGENT'
);


ALTER TYPE public."AnnouncementType" OWNER TO postgres;

--
-- Name: BackupStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BackupStatus" AS ENUM (
    'IN_PROGRESS',
    'SUCCESS',
    'FAILED'
);


ALTER TYPE public."BackupStatus" OWNER TO postgres;

--
-- Name: BudgetPeriod; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BudgetPeriod" AS ENUM (
    'MONTHLY',
    'WEEKLY'
);


ALTER TYPE public."BudgetPeriod" OWNER TO postgres;

--
-- Name: CategoryType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CategoryType" AS ENUM (
    'INCOME',
    'EXPENSE'
);


ALTER TYPE public."CategoryType" OWNER TO postgres;

--
-- Name: DebtType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DebtType" AS ENUM (
    'GIVEN',
    'TAKEN'
);


ALTER TYPE public."DebtType" OWNER TO postgres;

--
-- Name: RecurrenceFrequency; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RecurrenceFrequency" AS ENUM (
    'DAILY',
    'WEEKLY',
    'MONTHLY'
);


ALTER TYPE public."RecurrenceFrequency" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'USER',
    'MODERATOR',
    'ADMIN',
    'SUPER_ADMIN'
);


ALTER TYPE public."Role" OWNER TO postgres;

--
-- Name: TransactionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TransactionType" AS ENUM (
    'INCOME',
    'EXPENSE',
    'TRANSFER'
);


ALTER TYPE public."TransactionType" OWNER TO postgres;

--
-- Name: WalletType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."WalletType" AS ENUM (
    'CASH',
    'BANK',
    'MOBILE_BANKING'
);


ALTER TYPE public."WalletType" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_audit_logs (
    id text NOT NULL,
    admin_id text NOT NULL,
    action text NOT NULL,
    target_id text,
    target_type text,
    details jsonb,
    ip_address text,
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.admin_audit_logs OWNER TO postgres;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_settings (
    id text NOT NULL,
    user_id text NOT NULL,
    is_pin_enabled boolean DEFAULT false NOT NULL,
    pin_code_hash text,
    auto_lock_hours integer DEFAULT 1 NOT NULL,
    active_wallet_id text,
    language text DEFAULT 'en'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.app_settings OWNER TO postgres;

--
-- Name: budgets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budgets (
    id text NOT NULL,
    user_id text NOT NULL,
    category_id text NOT NULL,
    limit_amount double precision NOT NULL,
    period public."BudgetPeriod" DEFAULT 'MONTHLY'::public."BudgetPeriod" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.budgets OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    type public."CategoryType" NOT NULL,
    icon text NOT NULL,
    color text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: database_backup_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.database_backup_logs (
    id text NOT NULL,
    filename text NOT NULL,
    file_size_bytes integer,
    status public."BackupStatus" DEFAULT 'IN_PROGRESS'::public."BackupStatus" NOT NULL,
    triggered_by text DEFAULT 'CRON_AUTO'::text NOT NULL,
    recipient_email text,
    is_email_sent boolean DEFAULT false NOT NULL,
    error_message text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.database_backup_logs OWNER TO postgres;

--
-- Name: debts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.debts (
    id text NOT NULL,
    user_id text NOT NULL,
    wallet_id text,
    person_name text NOT NULL,
    type public."DebtType" NOT NULL,
    amount double precision NOT NULL,
    due_date text,
    is_cleared boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.debts OWNER TO postgres;

--
-- Name: global_category_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.global_category_templates (
    id text NOT NULL,
    name text NOT NULL,
    name_bn text,
    type public."CategoryType" NOT NULL,
    icon text NOT NULL,
    color text NOT NULL,
    is_default boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.global_category_templates OWNER TO postgres;

--
-- Name: notes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notes (
    id text NOT NULL,
    user_id text NOT NULL,
    title text NOT NULL,
    content text,
    is_completed boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.notes OWNER TO postgres;

--
-- Name: saving_goals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.saving_goals (
    id text NOT NULL,
    user_id text NOT NULL,
    goal_name text NOT NULL,
    target_amount double precision NOT NULL,
    current_amount double precision DEFAULT 0 NOT NULL,
    target_date text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.saving_goals OWNER TO postgres;

--
-- Name: saving_histories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.saving_histories (
    id text NOT NULL,
    saving_id text NOT NULL,
    wallet_id text NOT NULL,
    amount double precision NOT NULL,
    date text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.saving_histories OWNER TO postgres;

--
-- Name: system_announcements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_announcements (
    id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type public."AnnouncementType" DEFAULT 'INFO'::public."AnnouncementType" NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    starts_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(3) without time zone,
    created_by_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    target_email text,
    target_type text DEFAULT 'ALL'::text NOT NULL,
    target_user_id text,
    target_emails text[] DEFAULT ARRAY[]::text[],
    target_user_ids text[] DEFAULT ARRAY[]::text[]
);


ALTER TABLE public.system_announcements OWNER TO postgres;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    id text NOT NULL,
    user_id text NOT NULL,
    type public."TransactionType" NOT NULL,
    amount double precision NOT NULL,
    wallet_id text NOT NULL,
    to_wallet_id text,
    category_id text,
    date text NOT NULL,
    note text,
    is_recurring boolean DEFAULT false NOT NULL,
    frequency public."RecurrenceFrequency",
    next_execution_date text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    phone text,
    role public."Role" DEFAULT 'USER'::public."Role" NOT NULL,
    avatar text,
    currency text DEFAULT 'BDT (৳)'::text NOT NULL,
    bio text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    status public."AccountStatus" DEFAULT 'ACTIVE'::public."AccountStatus" NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: wallets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wallets (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    type public."WalletType" DEFAULT 'CASH'::public."WalletType" NOT NULL,
    balance double precision DEFAULT 0 NOT NULL,
    icon text DEFAULT 'Wallet'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.wallets OWNER TO postgres;

--
-- Data for Name: admin_audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_audit_logs (id, admin_id, action, target_id, target_type, details, ip_address, user_agent, created_at) FROM stdin;
812c24eb-2273-48e0-afb1-d94f68506f00	0f8333c4-1880-4044-a051-c96b0aad17e7	ADMIN_LOGIN	0f8333c4-1880-4044-a051-c96b0aad17e7	USER	{"role": "SUPER_ADMIN", "email": "dev.tajulislam505@gmail.com"}	\N	\N	2026-09-14 08:10:30.364
9881b06a-8f17-4ab1-8388-43b5baead99e	0f8333c4-1880-4044-a051-c96b0aad17e7	ADMIN_LOGIN	0f8333c4-1880-4044-a051-c96b0aad17e7	USER	{"role": "SUPER_ADMIN", "email": "dev.tajulislam505@gmail.com"}	\N	\N	2026-09-14 08:13:53.382
99b989a0-cacc-4204-9623-666416be2e1b	0f8333c4-1880-4044-a051-c96b0aad17e7	PURGE_CACHE	\N	SYSTEM	{}	\N	\N	2026-09-14 08:47:53.647
61fac6a5-843d-43dc-8b56-cca2a322804f	0f8333c4-1880-4044-a051-c96b0aad17e7	PURGE_CACHE	\N	SYSTEM	{}	\N	\N	2026-09-14 08:47:54.863
20db1505-5ce9-4793-aa43-452b2c826e9c	0f8333c4-1880-4044-a051-c96b0aad17e7	PURGE_CACHE	\N	SYSTEM	{}	\N	\N	2026-09-15 05:40:40.684
5613d692-4b22-46d4-800b-d4d6c3e98db7	0f8333c4-1880-4044-a051-c96b0aad17e7	CREATE_ANNOUNCEMENT	ebe041e9-12a6-4a85-82c7-47eb02d5662c	ANNOUNCEMENT	{"title": "Announcements"}	\N	\N	2026-09-15 06:04:18.185
7c2e31b3-0c0d-4d14-8659-740edc3a069b	0f8333c4-1880-4044-a051-c96b0aad17e7	TOGGLE_ANNOUNCEMENT	ebe041e9-12a6-4a85-82c7-47eb02d5662c	ANNOUNCEMENT	{"isActive": false}	\N	\N	2026-09-15 06:21:31.177
f8a118d7-5e19-48be-9382-9506cd4349ab	0f8333c4-1880-4044-a051-c96b0aad17e7	TOGGLE_ANNOUNCEMENT	ebe041e9-12a6-4a85-82c7-47eb02d5662c	ANNOUNCEMENT	{"isActive": true}	\N	\N	2026-09-15 06:21:32.103
3dca6a1a-2ed6-457a-8c62-cca0fa6ff733	0f8333c4-1880-4044-a051-c96b0aad17e7	DELETE_ANNOUNCEMENT	ebe041e9-12a6-4a85-82c7-47eb02d5662c	ANNOUNCEMENT	{}	\N	\N	2026-09-15 06:32:35.074
5a26fb2e-a6c4-46fc-b47f-375b58cf85a1	0f8333c4-1880-4044-a051-c96b0aad17e7	CREATE_ANNOUNCEMENT	cc30de01-800c-478d-a15f-03ce6b44ba75	ANNOUNCEMENT	{"title": "test", "targetType": "USER", "targetEmail": "mdtajulislam50599@gmail.com"}	\N	\N	2026-09-15 06:33:53.094
4b20f891-69bc-4514-95ff-ea969c868d7e	0f8333c4-1880-4044-a051-c96b0aad17e7	DELETE_ANNOUNCEMENT	cc30de01-800c-478d-a15f-03ce6b44ba75	ANNOUNCEMENT	{}	\N	\N	2026-09-15 06:34:18.144
80b634bf-b7cc-4102-9d24-ac8123012b09	0f8333c4-1880-4044-a051-c96b0aad17e7	CREATE_ANNOUNCEMENT	a174a275-eb74-4927-bb2d-066967cb8b59	ANNOUNCEMENT	{"title": "frthset", "targetType": "USER", "targetEmail": "dev.tajulislam505@gmail.com"}	\N	\N	2026-09-15 06:44:26.165
98db3154-b2c3-48dc-80e7-8019d10f3727	0f8333c4-1880-4044-a051-c96b0aad17e7	DELETE_ANNOUNCEMENT	a174a275-eb74-4927-bb2d-066967cb8b59	ANNOUNCEMENT	{}	\N	\N	2026-09-15 06:44:39.557
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_settings (id, user_id, is_pin_enabled, pin_code_hash, auto_lock_hours, active_wallet_id, language, created_at, updated_at) FROM stdin;
3c3be332-0c32-4a1e-a9cf-b1fc91fbd9d6	0f8333c4-1880-4044-a051-c96b0aad17e7	f	\N	1	b5129c04-26b6-4c7a-9532-c4dac061b29a	en	2026-09-14 04:09:11.354	2026-09-14 04:09:11.354
a0b30e4a-5981-43e0-b074-8c1e656eaafc	02c23f0b-a426-441c-ad13-b7485baea226	f	\N	1	b9723484-9859-4866-9e42-9294cc57f7db	en	2026-09-14 04:25:59.587	2026-09-14 04:25:59.587
a915d2ff-d1ae-4c01-9a77-efe4028bd3d8	b91b0c39-c7eb-4a65-a3c7-98f2b8e12210	f	\N	1	4b8e6ee3-68c2-4e2e-a553-a1d88bd4f198	en	2026-09-14 04:28:24.801	2026-09-14 04:28:24.801
4003cb48-d705-4fd2-a062-22cb44f6f3a7	981145c3-46c3-46c7-8c43-e65759a9e83a	f	\N	1	fb1a359b-8d0b-435f-8617-cf544ee75cb9	bn	2026-09-14 05:02:47.256	2026-09-14 05:02:47.256
416861a4-0859-4d8b-afde-b7d6df5aee49	2c37d338-a8eb-48e2-bbde-624241b1d073	f	\N	1	ba86040f-134e-49d1-9896-43c4ce30b542	bn	2026-09-14 05:32:08.243	2026-09-14 05:32:08.243
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budgets (id, user_id, category_id, limit_amount, period, created_at, updated_at) FROM stdin;
90c9afac-eccc-4ada-a667-853bfa685546	2c37d338-a8eb-48e2-bbde-624241b1d073	5094b007-9e4f-4b22-8a5d-7f2a3001531b	1000	MONTHLY	2026-09-14 05:38:25.506	2026-09-14 05:38:25.506
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, user_id, name, type, icon, color, created_at, updated_at) FROM stdin;
277592b3-0ed7-4e2d-b0a1-8289d08d7823	0f8333c4-1880-4044-a051-c96b0aad17e7	Food & Dining	EXPENSE	UtensilsCrossed	#38bdf8	2026-09-14 04:09:11.355	2026-09-14 04:09:11.355
12ad2fd7-61c2-41d1-8d8c-71233b78938a	0f8333c4-1880-4044-a051-c96b0aad17e7	Transportation	EXPENSE	Bus	#f59e0b	2026-09-14 04:09:11.355	2026-09-14 04:09:11.355
2c21f306-984e-4fd0-9d65-d7ca96773453	0f8333c4-1880-4044-a051-c96b0aad17e7	Salary & Income	INCOME	Briefcase	#22c55e	2026-09-14 04:09:11.355	2026-09-14 04:09:11.355
72834f8f-1e1b-4133-a965-115c3f97c90f	02c23f0b-a426-441c-ad13-b7485baea226	Food & Dining	EXPENSE	UtensilsCrossed	#38bdf8	2026-09-14 04:25:59.588	2026-09-14 04:25:59.588
d6dcaabb-ada4-4785-91ce-0d1decf9eee6	02c23f0b-a426-441c-ad13-b7485baea226	Transportation	EXPENSE	Bus	#f59e0b	2026-09-14 04:25:59.588	2026-09-14 04:25:59.588
a0c5a1af-ba34-4546-ac5f-f6dea5f02d47	02c23f0b-a426-441c-ad13-b7485baea226	Salary & Income	INCOME	Briefcase	#22c55e	2026-09-14 04:25:59.588	2026-09-14 04:25:59.588
47d8cf69-b1fb-4d38-b3ff-f9f7f2282233	02c23f0b-a426-441c-ad13-b7485baea226	Initial Balance	INCOME	Wallet	#22c55e	2026-09-14 04:27:08.609	2026-09-14 04:27:08.609
5f34092d-16b3-4c70-9846-95d9b1f5de0e	b91b0c39-c7eb-4a65-a3c7-98f2b8e12210	Food & Dining	EXPENSE	UtensilsCrossed	#38bdf8	2026-09-14 04:28:24.802	2026-09-14 04:28:24.802
7acf9a36-e693-419c-a8d9-045bf7f5d5e8	b91b0c39-c7eb-4a65-a3c7-98f2b8e12210	Transportation	EXPENSE	Bus	#f59e0b	2026-09-14 04:28:24.802	2026-09-14 04:28:24.802
13074b26-0c15-49e7-a1a9-77493d517bb7	b91b0c39-c7eb-4a65-a3c7-98f2b8e12210	Salary & Income	INCOME	Briefcase	#22c55e	2026-09-14 04:28:24.802	2026-09-14 04:28:24.802
728a8f6a-de0c-4223-b39d-cc6f3c3c7222	02c23f0b-a426-441c-ad13-b7485baea226	দেনা-পাওনা (Debts & Loans)	EXPENSE	ArrowLeftRight	#8b5cf6	2026-09-14 04:33:38.719	2026-09-14 04:33:38.719
94caa315-1cbd-48a4-b8ac-1c884af5f2f4	981145c3-46c3-46c7-8c43-e65759a9e83a	Food & Dining	EXPENSE	UtensilsCrossed	#38bdf8	2026-09-14 05:02:47.257	2026-09-14 05:02:47.257
b985d0c8-b510-4166-ad03-805c38e64378	981145c3-46c3-46c7-8c43-e65759a9e83a	House Rent	EXPENSE	Home	#6366f1	2026-09-14 05:02:47.257	2026-09-14 05:02:47.257
f7944190-3dd1-44ed-a48d-fc2369f349de	981145c3-46c3-46c7-8c43-e65759a9e83a	Transportation	EXPENSE	Bus	#0ea5e9	2026-09-14 05:02:47.257	2026-09-14 05:02:47.257
46201b1c-9dfd-428e-9f5d-059164e6a649	981145c3-46c3-46c7-8c43-e65759a9e83a	Shopping	EXPENSE	ShoppingBag	#8b5cf6	2026-09-14 05:02:47.257	2026-09-14 05:02:47.257
2bad4bd6-22f3-4db1-8efb-bf93add7dd0e	981145c3-46c3-46c7-8c43-e65759a9e83a	Bills & Utilities	EXPENSE	Receipt	#64748b	2026-09-14 05:02:47.257	2026-09-14 05:02:47.257
a0a0c9eb-624f-4298-bedd-a7a4a23bc8d7	981145c3-46c3-46c7-8c43-e65759a9e83a	Salary & Income	INCOME	Briefcase	#22c55e	2026-09-14 05:02:47.257	2026-09-14 05:02:47.257
bbda623d-25c9-4227-a818-2658b7e42167	981145c3-46c3-46c7-8c43-e65759a9e83a	Freelancing	INCOME	Laptop	#14b8a6	2026-09-14 05:02:47.257	2026-09-14 05:02:47.257
5094b007-9e4f-4b22-8a5d-7f2a3001531b	2c37d338-a8eb-48e2-bbde-624241b1d073	Food & Dining	EXPENSE	UtensilsCrossed	#38bdf8	2026-09-14 05:32:08.244	2026-09-14 05:32:08.244
c54f3390-510e-45d7-b364-24e2a18b825f	2c37d338-a8eb-48e2-bbde-624241b1d073	House Rent	EXPENSE	Home	#6366f1	2026-09-14 05:32:08.244	2026-09-14 05:32:08.244
61ce80ab-35d3-4bd9-97ff-5be79f0cc9a2	2c37d338-a8eb-48e2-bbde-624241b1d073	Transportation	EXPENSE	Bus	#0ea5e9	2026-09-14 05:32:08.244	2026-09-14 05:32:08.244
89efb560-a3be-47fe-88c3-c02c66e9e69b	2c37d338-a8eb-48e2-bbde-624241b1d073	Shopping	EXPENSE	ShoppingBag	#8b5cf6	2026-09-14 05:32:08.244	2026-09-14 05:32:08.244
ad544bc7-03b6-4bcf-996c-32cc923634d2	2c37d338-a8eb-48e2-bbde-624241b1d073	Bills & Utilities	EXPENSE	Receipt	#64748b	2026-09-14 05:32:08.244	2026-09-14 05:32:08.244
755cac5d-554c-4dfe-9bdf-26aa1f4609e8	2c37d338-a8eb-48e2-bbde-624241b1d073	Salary & Income	INCOME	Briefcase	#22c55e	2026-09-14 05:32:08.244	2026-09-14 05:32:08.244
0b63f63c-4f35-40e0-9839-1d5690ed21f4	2c37d338-a8eb-48e2-bbde-624241b1d073	Freelancing	INCOME	Laptop	#14b8a6	2026-09-14 05:32:08.244	2026-09-14 05:32:08.244
\.


--
-- Data for Name: database_backup_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.database_backup_logs (id, filename, file_size_bytes, status, triggered_by, recipient_email, is_email_sent, error_message, created_at) FROM stdin;
a8aa8976-c65e-4320-8b59-26d0c765d0dd	amar_khoroch_backup_2026-09-14T06-56-59-774Z.zip	\N	FAILED	TEST_SCRIPT	dev.tajulislam505@gmail.com	f	archiver is not a function	2026-09-14 06:56:59.776
eaf71222-0fcb-49bb-9c5e-af1692985ba1	amar_khoroch_backup_2026-09-14T06-58-26-268Z.zip	6964	SUCCESS	TEST_SUITE	dev.tajulislam505@gmail.com	f	\N	2026-09-14 06:58:26.27
7be49682-5f3c-4de0-bbac-2ee0f0233b7c	amar_khoroch_backup_2026-09-14T20-00-00-037Z.zip	7228	SUCCESS	CRON_DAILY_AUTO	dev.tajulislam505@gmail.com	f	\N	2026-09-14 20:00:00.061
59063dae-6ceb-4f22-98b0-794ccf2d22cb	amar_khoroch_backup_2026-09-15T03-42-51-980Z.zip	7293	SUCCESS	ADMIN_UI (dev.tajulislam505@gmail.com)	dev.tajulislam505@gmail.com	f	\N	2026-09-15 03:42:51.98
b4e99050-806e-485c-8896-c6a3358b6b4f	test_backup_2026-09-15T05-03-46-421Z.zip	7276	SUCCESS	LIVE_VERIFICATION_TEST	dev.tajulislam505@gmail.com	t	\N	2026-09-15 05:03:51.11
94d3cec8-efd4-4c57-a765-504836bdf239	amar_khoroch_backup_2026-09-15T05-10-17-296Z.zip	7425	SUCCESS	ADMIN_UI (dev.tajulislam505@gmail.com)	dev.tajulislam505@gmail.com	f	SMTP_PASS is not configured in .env	2026-09-15 05:10:17.297
11264169-2674-4a44-a03a-fa091ecc27cc	amar_khoroch_backup_2026-09-15T05-21-57-449Z.zip	7512	SUCCESS	ADMIN_UI (dev.tajulislam505@gmail.com)	dev.tajulislam505@gmail.com	t	\N	2026-09-15 05:21:57.45
85bb818d-7555-4cf7-9d8c-4d8084e541d0	amar_khoroch_backup_2026-09-15T08-03-51-609Z.zip	8559	SUCCESS	ADMIN_UI (dev.tajulislam505@gmail.com)	dev.tajulislam505@gmail.com	t	\N	2026-09-15 08:03:51.611
c50a2ab2-a976-4244-a651-5bf1e8b8739d	amar_khoroch_backup_2026-09-15T08-44-08-919Z.zip	\N	IN_PROGRESS	SAFETY_PRE_RESTORE (dev.tajulislam505@gmail.com)	dev.tajulislam505@gmail.com	f	\N	2026-09-15 08:44:08.92
\.


--
-- Data for Name: debts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.debts (id, user_id, wallet_id, person_name, type, amount, due_date, is_cleared, created_at, updated_at) FROM stdin;
feb2a9d3-0aaa-4daa-9efe-fb99044f664b	02c23f0b-a426-441c-ad13-b7485baea226	94c4507a-f1b5-4999-82b6-4f5b2560e428	Rafiq	GIVEN	200	\N	f	2026-09-14 04:33:38.716	2026-09-14 04:33:38.716
\.


--
-- Data for Name: global_category_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.global_category_templates (id, name, name_bn, type, icon, color, is_default, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notes (id, user_id, title, content, is_completed, created_at, updated_at) FROM stdin;
336beabd-d9c4-46aa-867f-58057085074a	981145c3-46c3-46c7-8c43-e65759a9e83a	Buy monthly groceries	Rice, Oil, Sugar, Spices	f	2026-09-14 05:23:38.946	2026-09-14 05:23:38.946
\.


--
-- Data for Name: saving_goals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.saving_goals (id, user_id, goal_name, target_amount, current_amount, target_date, created_at, updated_at) FROM stdin;
8554504d-6230-4546-bf85-32c71d7f6db1	2c37d338-a8eb-48e2-bbde-624241b1d073	iphon 19	2000	1000	2026-09-14	2026-09-14 05:40:35.193	2026-09-14 05:40:43.982
\.


--
-- Data for Name: saving_histories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.saving_histories (id, saving_id, wallet_id, amount, date, created_at) FROM stdin;
370583da-37ad-4d50-b02b-d33ef20d7596	8554504d-6230-4546-bf85-32c71d7f6db1	ba86040f-134e-49d1-9896-43c4ce30b542	500	2026-09-14	2026-09-14 05:40:35.224
17996045-bb41-4413-85ce-7683b1d5c9b8	8554504d-6230-4546-bf85-32c71d7f6db1	ba86040f-134e-49d1-9896-43c4ce30b542	500	2026-09-14	2026-09-14 05:40:43.987
\.


--
-- Data for Name: system_announcements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_announcements (id, title, message, type, is_active, starts_at, expires_at, created_by_id, created_at, updated_at, target_email, target_type, target_user_id, target_emails, target_user_ids) FROM stdin;
ce140ad6-bbf3-42b2-94bf-a782a9805d8f	সিস্টেম মেইনটেন্যান্স বিজ্ঞপ্তি	সম্মানিত গ্রাহকবৃন্দ, আজ রাত ১২:০০ টা থেকে ১:০০ টা পর্যন্ত সার্ভার নিয়মিত আপগ্রেড ও ব্যাকআপ চলবে।	WARNING	t	2026-09-15 06:33:28.21	2026-09-16 06:33:28.209	0f8333c4-1880-4044-a051-c96b0aad17e7	2026-09-15 06:33:28.21	2026-09-15 06:33:28.21	\N	ALL	\N	{}	{}
efb7be17-0903-463b-92a5-20f5cbc8ec56	আপনার প্রোফাইল ভেরিফিকেশন সম্পন্ন হয়েছে	অভিনন্দন তাজুল ইসলাম! আপনার অ্যাকাউন্টের নিরাপত্তা যাচাইকরণ সফলভাবে সম্পন্ন হয়েছে।	INFO	t	2026-09-15 06:33:28.212	2026-09-18 06:33:28.211	0f8333c4-1880-4044-a051-c96b0aad17e7	2026-09-15 06:33:28.212	2026-09-15 06:33:28.212	mdtajulislam50599@gmail.com	USER	\N	{}	{}
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (id, user_id, type, amount, wallet_id, to_wallet_id, category_id, date, note, is_recurring, frequency, next_execution_date, created_at, updated_at) FROM stdin;
98e3d6a1-e344-42c5-bbe1-3c9f5ea8bb19	02c23f0b-a426-441c-ad13-b7485baea226	INCOME	500	94c4507a-f1b5-4999-82b6-4f5b2560e428	\N	47d8cf69-b1fb-4d38-b3ff-f9f7f2282233	2026-09-14	bKash - প্রাথমিক ব্যালেন্স	f	\N	\N	2026-09-14 04:27:08.61	2026-09-14 04:27:08.61
2ba4e62f-3eae-4840-9515-aadd7af4adc0	02c23f0b-a426-441c-ad13-b7485baea226	EXPENSE	100	94c4507a-f1b5-4999-82b6-4f5b2560e428	\N	72834f8f-1e1b-4133-a965-115c3f97c90f	2026-09-14	Test tea	f	\N	\N	2026-09-14 04:27:20.706	2026-09-14 04:27:20.706
3dee7230-22db-4c28-909b-1ac417fc9e24	02c23f0b-a426-441c-ad13-b7485baea226	TRANSFER	50	94c4507a-f1b5-4999-82b6-4f5b2560e428	b9723484-9859-4866-9e42-9294cc57f7db	\N	2026-09-14	\N	f	\N	\N	2026-09-14 04:28:38.728	2026-09-14 04:28:38.728
55584921-cc7e-4ba5-8391-3d90a3e056ef	02c23f0b-a426-441c-ad13-b7485baea226	EXPENSE	200	94c4507a-f1b5-4999-82b6-4f5b2560e428	\N	728a8f6a-de0c-4223-b39d-cc6f3c3c7222	2026-09-14	[DEBT_INIT:feb2a9d3-0aaa-4daa-9efe-fb99044f664b] Rafiq-কে ধার দেওয়া হয়েছে	f	\N	\N	2026-09-14 04:33:38.72	2026-09-14 04:33:38.72
60c9402d-d0ed-4451-8996-91f8d1873635	981145c3-46c3-46c7-8c43-e65759a9e83a	INCOME	50000	fb1a359b-8d0b-435f-8617-cf544ee75cb9	\N	a0a0c9eb-624f-4298-bedd-a7a4a23bc8d7	2026-09-14	Monthly Salary	f	\N	\N	2026-09-14 05:08:08.809	2026-09-14 05:08:08.809
fe8dcf96-0db8-49aa-9549-f0179d6a5349	981145c3-46c3-46c7-8c43-e65759a9e83a	EXPENSE	1500	fb1a359b-8d0b-435f-8617-cf544ee75cb9	\N	94caa315-1cbd-48a4-b8ac-1c884af5f2f4	2026-09-14	Dinner with friends	f	\N	\N	2026-09-14 05:23:12.273	2026-09-14 05:23:12.273
644901d3-6316-4c56-8fc0-c54bc3a28690	2c37d338-a8eb-48e2-bbde-624241b1d073	EXPENSE	455	ba86040f-134e-49d1-9896-43c4ce30b542	\N	5094b007-9e4f-4b22-8a5d-7f2a3001531b	2026-09-14	fghy	f	\N	\N	2026-09-14 05:32:57.949	2026-09-14 05:32:57.949
de1f2126-2f74-439b-bcf2-f4692d8f2a91	2c37d338-a8eb-48e2-bbde-624241b1d073	INCOME	500	ba86040f-134e-49d1-9896-43c4ce30b542	\N	755cac5d-554c-4dfe-9bdf-26aa1f4609e8	2026-09-14	\N	f	\N	\N	2026-09-14 05:33:13.015	2026-09-14 05:33:13.015
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, password_hash, phone, role, avatar, currency, bio, created_at, updated_at, status) FROM stdin;
0f8333c4-1880-4044-a051-c96b0aad17e7	MD Tajul Islam	dev.tajulislam505@gmail.com	$2a$10$iqaUgokW.n9QfJRCmdI.v.16/EDGyfAZnzXcJV/2anL28675e.vxe	01991311505	SUPER_ADMIN	\N	BDT (৳)	\N	2026-09-14 04:09:11.352	2026-09-14 04:09:11.352	ACTIVE
02c23f0b-a426-441c-ad13-b7485baea226	Test User	testdebug123@example.com	$2a$10$w0Nz/XQC79ryuJ4WZUS6p.n4cF5pGviT5bj4JmY96oxRPXEMUnyre	+8801712345678	USER	\N	BDT (৳)	\N	2026-09-14 04:25:59.585	2026-09-14 04:25:59.585	ACTIVE
b91b0c39-c7eb-4a65-a3c7-98f2b8e12210	Google Test User	googletest@example.com	$2a$10$8gCBQmEW5fg7UFH3rNi3XO.J/uaatq6JUH47Gqr/V3tL/HCUjkKSO	\N	USER	https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80	BDT (৳)	\N	2026-09-14 04:28:24.799	2026-09-14 04:28:24.799	ACTIVE
981145c3-46c3-46c7-8c43-e65759a9e83a	Test User	test_verify_1789362167@example.com	$2a$10$2skHiXkd5K6fhLQXhzsUheGau0ZBEKr4.6HCcNyW3NqIP.5qumnwq	+8801700000000	USER	\N	BDT (৳)	\N	2026-09-14 05:02:47.25	2026-09-14 05:02:47.25	ACTIVE
2c37d338-a8eb-48e2-bbde-624241b1d073	MD Tajul Islam	mdtajulislam50599@gmail.com	$2a$10$qkxe5wFub57u6gK5aGb1seLBGrR1aeykgB.s4iBZk7H/6em1QKpxO	\N	USER	https://lh3.googleusercontent.com/a/ACg8ocJR41mgl9kSx4tQrdnBukuNLEiEJ0OTHqPwd8-e6ut-6u9f4lI=s96-c	BDT (৳)	\N	2026-09-14 05:32:08.241	2026-09-14 05:32:08.241	ACTIVE
\.


--
-- Data for Name: wallets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wallets (id, user_id, name, type, balance, icon, created_at, updated_at) FROM stdin;
b5129c04-26b6-4c7a-9532-c4dac061b29a	0f8333c4-1880-4044-a051-c96b0aad17e7	Cash Wallet	CASH	0	Wallet	2026-09-14 04:09:11.353	2026-09-14 04:09:11.353
4b8e6ee3-68c2-4e2e-a553-a1d88bd4f198	b91b0c39-c7eb-4a65-a3c7-98f2b8e12210	Cash Wallet	CASH	0	Wallet	2026-09-14 04:28:24.8	2026-09-14 04:28:24.8
b9723484-9859-4866-9e42-9294cc57f7db	02c23f0b-a426-441c-ad13-b7485baea226	Cash Wallet	CASH	50	Wallet	2026-09-14 04:25:59.586	2026-09-14 04:28:38.727
94c4507a-f1b5-4999-82b6-4f5b2560e428	02c23f0b-a426-441c-ad13-b7485baea226	bKash	MOBILE_BANKING	150	Smartphone	2026-09-14 04:27:08.606	2026-09-14 04:33:38.721
68107f77-6c02-41af-8b2d-ed2b0bbda831	981145c3-46c3-46c7-8c43-e65759a9e83a	Bank Account	BANK	0	Landmark	2026-09-14 05:02:47.254	2026-09-14 05:02:47.254
084a42cf-66c3-47a9-a817-741613e4ad20	981145c3-46c3-46c7-8c43-e65759a9e83a	bKash	MOBILE_BANKING	0	Smartphone	2026-09-14 05:02:47.254	2026-09-14 05:02:47.254
fb1a359b-8d0b-435f-8617-cf544ee75cb9	981145c3-46c3-46c7-8c43-e65759a9e83a	Cash Wallet	CASH	48500	Wallet	2026-09-14 05:02:47.252	2026-09-14 05:23:12.272
4ec6b797-1d41-43f0-b063-b3fd2b60412a	2c37d338-a8eb-48e2-bbde-624241b1d073	Bank Account	BANK	0	Landmark	2026-09-14 05:32:08.243	2026-09-14 05:32:08.243
354db363-7435-43e2-8dd1-821f50623186	2c37d338-a8eb-48e2-bbde-624241b1d073	bKash	MOBILE_BANKING	0	Smartphone	2026-09-14 05:32:08.243	2026-09-14 05:32:08.243
ba86040f-134e-49d1-9896-43c4ce30b542	2c37d338-a8eb-48e2-bbde-624241b1d073	Cash Wallet	CASH	-955	Wallet	2026-09-14 05:32:08.242	2026-09-14 05:40:43.976
\.


--
-- Name: admin_audit_logs admin_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_audit_logs
    ADD CONSTRAINT admin_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: database_backup_logs database_backup_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.database_backup_logs
    ADD CONSTRAINT database_backup_logs_pkey PRIMARY KEY (id);


--
-- Name: debts debts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_pkey PRIMARY KEY (id);


--
-- Name: global_category_templates global_category_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.global_category_templates
    ADD CONSTRAINT global_category_templates_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: saving_goals saving_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saving_goals
    ADD CONSTRAINT saving_goals_pkey PRIMARY KEY (id);


--
-- Name: saving_histories saving_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saving_histories
    ADD CONSTRAINT saving_histories_pkey PRIMARY KEY (id);


--
-- Name: system_announcements system_announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_announcements
    ADD CONSTRAINT system_announcements_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (id);


--
-- Name: admin_audit_logs_action_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX admin_audit_logs_action_idx ON public.admin_audit_logs USING btree (action);


--
-- Name: admin_audit_logs_admin_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX admin_audit_logs_admin_id_idx ON public.admin_audit_logs USING btree (admin_id);


--
-- Name: app_settings_user_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX app_settings_user_id_key ON public.app_settings USING btree (user_id);


--
-- Name: budgets_user_id_category_id_period_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX budgets_user_id_category_id_period_key ON public.budgets USING btree (user_id, category_id, period);


--
-- Name: categories_user_id_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX categories_user_id_type_idx ON public.categories USING btree (user_id, type);


--
-- Name: debts_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX debts_user_id_idx ON public.debts USING btree (user_id);


--
-- Name: notes_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notes_user_id_idx ON public.notes USING btree (user_id);


--
-- Name: saving_goals_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX saving_goals_user_id_idx ON public.saving_goals USING btree (user_id);


--
-- Name: saving_histories_saving_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX saving_histories_saving_id_idx ON public.saving_histories USING btree (saving_id);


--
-- Name: saving_histories_wallet_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX saving_histories_wallet_id_idx ON public.saving_histories USING btree (wallet_id);


--
-- Name: transactions_user_id_category_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX transactions_user_id_category_id_idx ON public.transactions USING btree (user_id, category_id);


--
-- Name: transactions_user_id_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX transactions_user_id_date_idx ON public.transactions USING btree (user_id, date);


--
-- Name: transactions_user_id_wallet_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX transactions_user_id_wallet_id_idx ON public.transactions USING btree (user_id, wallet_id);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: wallets_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX wallets_user_id_idx ON public.wallets USING btree (user_id);


--
-- Name: app_settings app_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: budgets budgets_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: budgets budgets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categories categories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: debts debts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: debts debts_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.wallets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: notes notes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: saving_goals saving_goals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saving_goals
    ADD CONSTRAINT saving_goals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: saving_histories saving_histories_saving_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saving_histories
    ADD CONSTRAINT saving_histories_saving_id_fkey FOREIGN KEY (saving_id) REFERENCES public.saving_goals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: saving_histories saving_histories_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saving_histories
    ADD CONSTRAINT saving_histories_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.wallets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: transactions transactions_to_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_to_wallet_id_fkey FOREIGN KEY (to_wallet_id) REFERENCES public.wallets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transactions transactions_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.wallets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: wallets wallets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict TdnH9M4s5QMNGxDd5idVbPccCyDdttOkRDPsozdn2K3II9e5OLPfyb9irmh0tr0

